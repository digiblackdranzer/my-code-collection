import java.io.*;
public class Comparator {

	public static void main(String[] args) throws Exception
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Give complete path of file1");
		String p1=br.readLine();
		System.out.println("Give complete path of file2");
		String p2=br.readLine();
		File f1 = new File(p1);
		File f2 = new File(p2);
		FileInputStream fis1 = new FileInputStream(f1);
		FileInputStream fis2 = new FileInputStream(f2);
		BufferedReader bf1 = new BufferedReader(new InputStreamReader(fis1));
		BufferedReader bf2 = new BufferedReader(new InputStreamReader(fis2));
		String s1=bf1.readLine(),s2;
		while((s2=bf2.readLine())!=null)
		{
			try
			{
				System.out.println(s1);
				System.out.println(s2);
				if(s2.contains(s1)||s2.equals(s1)||s1.contains(s2))
				s1=bf1.readLine();
			}
			catch(NullPointerException npe)
			{
				System.out.println("Code is Word to Word Copied");
				break;
			}
			
		}
		if(bf1.readLine()==null)
		System.out.println("Code is Word to Word Copied");
		else
		System.out.println("Code is not Word to Word Copied");	
		bf1.close();
		bf2.close();
		fis1.close();
		fis2.close();
		fis1 = new FileInputStream(f1);
		fis2 = new FileInputStream(f2);
		bf1=new BufferedReader(new InputStreamReader(fis1));
		bf2=new BufferedReader(new InputStreamReader(fis2));
		String code1="",code2="";
		code1=Encoder(bf1);
		code2=Encoder(bf2);
		System.out.println(code1);
		System.out.println(code2);
		if(code2.contains(code1))
		System.out.println("Code Structure is copied with possible variable changed");	
	}
	
	static String Encoder(BufferedReader br) throws IOException
	{
		String c="",s;
		while((s=br.readLine())!=null)
		{
			if(s.equals(" "))
			continue;	
			if(s.contains("#"))
			c=c.concat("P");
			else
			{
				if(s.contains("int ")||s.contains("float ")||s.contains("char ")||s.contains("void ")||s.contains("long ")||s.contains("double ")||s.contains(" int ")||s.contains(" float ")||s.contains(" char ")||s.contains(" void ")||s.contains(" long ")||s.contains(" double "))
				c=c.concat("D");
				else
				{
					if(s.contains("if")||s.contains("else"))
					c=c.concat("C");
					else
					{
						if(s.contains("for")||s.contains("while"))
						c=c.concat("L");
						else
						c=c.concat("S");	
					}
				}
			}
		}	
		
		return c;
	}

}
